/* This file is auto generated, version 21 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#21 SMP Sat May 15 13:25:42 CST 2021"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "nylon"
#define LINUX_COMPILER "gcc (Ubuntu 9.3.0-17ubuntu1~20.04) 9.3.0, GNU ld (GNU Binutils for Ubuntu) 2.34"
